CIS*2750 Assignment 2
--------------------------------
Created By: Ryan Nesbitt
ID: 0915819

Assumptions I made about the assignment:
	-I used the up and down arrow keys instead of the page
	up and down, my mac doesn't have them
	-All posts will will added only using the ./post
	and all authors will be added using only ./addauthor
	and all streams will only be created using ./addauthor
	-That a message counts as read even if only part of it
    	is shown
